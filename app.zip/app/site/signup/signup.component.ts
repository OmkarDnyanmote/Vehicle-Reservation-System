import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder, ValidatorFn, ValidationErrors } from '@angular/forms';
import { user } from '../user';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
    costumer: user
    userService: UserServiceService
    signupForm: FormGroup
  constructor(private fb: FormBuilder) 
  {
    this.userService = new UserServiceService();
   }

  ngOnInit() {this.signupForm = this.fb.group({
    'firstName':new FormControl('',[Validators.required]),
    'lastName': new FormControl('', [Validators.required]),
    'userName': new FormControl('', [Validators.required, Validators.minLength(4)]),
    'password': new FormControl('', [Validators.required, Validators.minLength(8)]),
    'cpassword': new FormControl('', [Validators.required, Validators.minLength(8)])
  },{validator: this.MustMatch('password', 'cpassword')}
  );
  }

  onSubmit(){
    if(this.signupForm.invalid){
      return;
    }

    this.costumer.userFirstName=this.signupForm.value['firstName'];
    this.costumer.userLastName=this.signupForm.value['LastName'];
    this.costumer.userName = this.signupForm['userName'];
    this.costumer.userPassword = this.signupForm['password'];

    this.userService.addUser(this.costumer);
  }

  MustMatch(controlName: string, matchingControlName: string) {
    return (formGroup: FormGroup) => {
      const control = formGroup.controls[controlName];
      const matchingControl = formGroup.controls[matchingControlName];

      if (matchingControl.errors && !matchingControl.errors.mustMatch) {
        // return if another validator has already found an error on the matchingControl
        return;
      }

      // set error on matchingControl if validation fails
      if (control.value !== matchingControl.value) {
        matchingControl.setErrors({ mustMatch: true });
      } else {
        matchingControl.setErrors(null);
      }
    }
  }


}