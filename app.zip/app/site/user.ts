export interface user{
    userFirstName: string,
    userLastName: string,
    userPassword: string,
    userName: string
}