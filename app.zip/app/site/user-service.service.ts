import { Injectable } from '@angular/core';
import { user } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {
customerList: user[]
  constructor() {
    this.customerList= [{
      userFirstName: 'Omkar',
      userLastName: 'Dnyanmote',
      userPassword: 'abcd',
      userName: 'OmkarD'},
      {userFirstName: 'Akash',
        userLastName: 'Bansal',
        userPassword: 'aaaaa',
        userName: 'AkashB'}]
   }

   addUser(customerUser:user){
     this.customerList.push(customerUser);
   }
   getUser(){
     return this.customerList;
   }
}

