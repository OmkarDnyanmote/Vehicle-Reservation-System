import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FoodItemInfoComponent } from './food/item-info/food-item-info/food-item-info.component';
import { FoodMenuComponent } from './food/menu/food-menu/food-menu.component';
import { FoodServiceService } from './food/food-service.service';
import { FoodSearchComponent } from './food/search/food-search/food-search.component';
import { ShoppingCartComponent } from './shopping/cart/shopping-cart/shopping-cart.component';
import { SignupComponent } from './site/signup/signup.component';

import { ReactiveFormsModule, FormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    AppComponent,
    FoodItemInfoComponent,
    FoodMenuComponent,
    FoodSearchComponent,
    ShoppingCartComponent,
    SignupComponent,
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,  ReactiveFormsModule,
    FormsModule
  ],
  providers: [FoodServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
