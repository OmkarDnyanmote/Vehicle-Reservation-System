import { Component, OnInit } from '@angular/core';
import { FoodItem } from '../../FoodItem';
import { FoodServiceService } from '../../food-service.service';

@Component({
  selector: 'app-food-menu',
  templateUrl: './food-menu.component.html',
  styleUrls: ['./food-menu.component.css']
})
export class FoodMenuComponent implements OnInit {
  foodItemList: FoodItem[]
  foodService: FoodServiceService
  constructor() {
    this.foodService = new FoodServiceService()
   }

  ngOnInit() {
    this.foodItemList= this.foodService.getFoodItems();
  }

}
