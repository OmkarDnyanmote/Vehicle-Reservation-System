import { Component, OnInit } from '@angular/core';
import { FoodItem } from '../../FoodItem';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-food-item-info',
  templateUrl: './food-item-info.component.html',
  styleUrls: ['./food-item-info.component.css']
})
export class FoodItemInfoComponent implements OnInit {
foodItem: FoodItem
  constructor() {
    this.foodItem={
      id: 1,
      name: 'Sandwich',
      price: 100,
      dateOfLaunch: new Date(),
      freeDelivery: true,
      active: false,
      category: 'Main Course',
      image: 'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=753&q=80'
    }
   }

  ngOnInit() {
  }

}
