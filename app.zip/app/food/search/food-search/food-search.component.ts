import { Component} from '@angular/core';
import { FoodItem } from '../../FoodItem';
import { FoodServiceService } from '../../food-service.service';

@Component({
  selector: 'app-food-search',
  templateUrl: './food-search.component.html' 
})
export class FoodSearchComponent {
  fList: FoodItem[]
  foodService: FoodServiceService
  constructor(){
    this.foodService= new FoodServiceService();
    
  }

  ngOnInit(){
    this.fList = this.foodService.getFoodItems();

  }

  onInput(value: string){
   this.fList = null;
    this.fList = this.foodService.searchFoodItem(value);
  }

  onClick(value:string){
    this.fList = null;
    this.fList = this.foodService.searchFoodItem(value);
  }
}
