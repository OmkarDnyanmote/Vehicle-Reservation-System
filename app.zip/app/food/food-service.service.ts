import { Injectable } from '@angular/core';
import { FoodItem } from './FoodItem';
import { FoodItemInfoComponent } from './item-info/food-item-info/food-item-info.component';

@Injectable({
  providedIn: 'root'
})
export class FoodServiceService {
  foodItemList: FoodItem[]
  constructor() { 
    this.foodItemList=[
      {id: 1,
        name: 'Sandwich',
        price: 100,
        dateOfLaunch: new Date(),
        freeDelivery: true,
        active: false,
        category: 'Main Course',
      image:'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=753&q=80'},
        {id: 2,
          name: 'Burger',
          price: 56,
          dateOfLaunch: new Date(),
          freeDelivery: true,
          active: true,
          category: 'Main Course',
          image:'https://images.unsplash.com/photo-1512152272829-e3139592d56f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=750&q=80'},
          {id: 3,
            name: 'Pizza',
            price: 150,
            dateOfLaunch: new Date(),
            freeDelivery: false,
            active: false,
            category: 'Main Course',
            image:'https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=755&q=80'},
            {id: 4,
              name: 'French Fries',
              price: 25,
              dateOfLaunch: new Date(),
              freeDelivery: false,
              active: true,
              category: 'Starter',
              image:'https://images.unsplash.com/photo-1526230427044-d092040d48dc?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=750&q=80'},
              {id: 5,
                name: 'Chocolate Brownie',
                price: 250,
                dateOfLaunch: new Date(),
                freeDelivery: true,
                active: false,
                category: 'Dessert',
                image:'https://images.unsplash.com/photo-1564355808539-22fda35bed7e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=730&q=80'}
    ]
  }

  getFoodItems(){
    return this.foodItemList;
  }

  searchFoodItem(value:string):FoodItem[]{
   let foodItemSearch: FoodItem[]=[];
    this.foodItemList.forEach(foodItem => {
      if(foodItem.name.toLowerCase().includes(value.toLowerCase())){
        foodItemSearch.push(foodItem);}
    });
    return foodItemSearch;
  }
}
