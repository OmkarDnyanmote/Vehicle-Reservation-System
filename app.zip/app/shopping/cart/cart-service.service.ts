import { Injectable } from '@angular/core';
import { Cart } from '../Cart';

@Injectable({
  providedIn: 'root'
})
export class CartServiceService {
  cartList: Cart[]
  constructor() { 
    this.cartList=[
      {id: 1,
        name: 'Sandwich',
        price: 100,
        freeDelivery: true,
        category: 'Main Course',
      image:'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=753&q=80'},
        {id: 2,
          name: 'Burger',
          price: 56,
          freeDelivery: true,
          category: 'Main Course',
          image:'https://images.unsplash.com/photo-1512152272829-e3139592d56f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=750&q=80'},
          {id: 3,
            name: 'Pizza',
            price: 150,
            freeDelivery: false,
            category: 'Main Course',
            image:'https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=755&q=80'},
            
            
    ]
  }

  getCartItem(){
    return this.cartList;
  }

  calculateTotal():number{
    let total=0;
    this.cartList.forEach(cartItem => {
      total = total + cartItem.price;
    });
    return total;
  }
}
