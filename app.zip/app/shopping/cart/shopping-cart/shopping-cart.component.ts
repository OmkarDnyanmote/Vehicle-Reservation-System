import { Component, OnInit, Output } from '@angular/core';
import { Cart } from '../../Cart';
import { CartServiceService } from '../cart-service.service';
import { createHostListener } from '@angular/compiler/src/core';
import { EventEmitter } from 'protractor';

@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.css']
})
export class ShoppingCartComponent implements OnInit {
  total:number
  cartItem: Cart
  cartService: CartServiceService
  cartList: Cart[]

  constructor() { 
    this.cartService = new CartServiceService();
   
  }

  ngOnInit() {
    this.cartList=this.cartService.getCartItem();
    this.total = this.cartService.calculateTotal();
  }


}
