export interface Cart{
    id: number;
    name: string;
    price: number;
    freeDelivery: boolean;
    category: string;
    image: string;
}